import numpy as np
import pandas as pd
from io import BytesIO
import os

# electron charge
e = -1.602176634 * pow(10, -19) # coulombs
# bohr radius
a_0 = 5.29 * pow(10, -11) # meters
# periodic table that is in terms of the amino acid abbreviations
electron_orbitals = pd.read_excel("../MarkovProprietary/pipelinestages/make_tables/excel/orbitals.xlsx").to_numpy()

# periodic table that is in terms of the electron orbitals
periodic_table = pd.read_excel("../MarkovProprietary/pipelinestages/make_tables/excel/periodic_table.xlsx").to_numpy()

# energies for every orbital per element in the periodic table
energies = pd.read_excel("../MarkovProprietary/pipelinestages/make_tables//excel/energies.xlsx").to_numpy()

# know atomic radii for every element in the periodic table
atomic_radii = pd.read_excel("../MarkovProprietary/pipelinestages/make_tables/excel/radii.xlsx").to_numpy()

# dictionary that maps abbreviations to orbitals
periodic_dict = {}

# dictionary that maps the names of the elements in the periodic table to their outermost electron orbital shells
for i in range(0, 10):
    for j in range(0, 18):
        periodic_dict[periodic_table[i][j]] = electron_orbitals[i][j]

# copy pasted from excel spreadsheet
E_n = [-1 * pow(e, 2) / (2 * a_0),
       -1 * pow(e, 2) / (8 * a_0),
       -1 * pow(e, 2) / (8 * a_0),
       -1 * pow(e, 2) / (18 * a_0),
       -1 * pow(e, 2) / (18 * a_0),
       -1 * pow(e, 2) / (18 * a_0),
       -1 * pow(e, 2) / (32 * a_0),
       -1 * pow(e, 2) / (32 * a_0),
       -1 * pow(e, 2) / (32 * a_0),
       -1 * pow(e, 2) / (32 * a_0),
       -1 * pow(e, 2) / (50 * a_0),
       -1 * pow(e, 2) / (50 * a_0),
       -1 * pow(e, 2) / (50 * a_0),
       -1 * pow(e, 2) / (50 * a_0),
       -1 * pow(e, 2) / (72 * a_0),
       -1 * pow(e, 2) / (72 * a_0),
       -1 * pow(e, 2) / (72 * a_0),
        1 * pow(e, 2) / (72 * a_0),
       -1 * pow(e, 2) / (98 * a_0),
       -1 * pow(e, 2) / (98 * a_0)]

energies = np.hstack((energies, np.array(E_n)[:, np.newaxis]))

# dictionary that maps orbitals to energies
orbital_dict = {}

for i in range(0, 20):
    orbital_dict[energies[i][2]] = energies[i][5]

# dictionary that maps the names of the elements in the periodic table to their outermost electron orbital shells
atomic_radii_dict = {}

for i in range(0, 99):
    atomic_radii_dict[atomic_radii[i][1]] = atomic_radii[i][3]
